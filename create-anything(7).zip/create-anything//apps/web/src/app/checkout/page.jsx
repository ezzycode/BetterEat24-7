"use client";

import React, { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { CreditCard, Banknote, DollarSign, AlertCircle } from "lucide-react";
import { useTheme } from "@/contexts/ThemeContext";
import useUser from "@/utils/useUser";

export default function CheckoutPage() {
  const { isDark } = useTheme();
  const { data: user } = useUser();
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState("stripe");
  const [cartTotal, setCartTotal] = useState(0);
  const [bankDetails, setBankDetails] = useState({
    account_holder: "",
    account_number: "",
    bank_name: "",
    routing_number: "",
  });

  const paymentMethods = [
    {
      id: "stripe",
      name: "Credit/Debit Card",
      description: "Visa, Mastercard, American Express",
      icon: CreditCard,
      color: "blue",
    },
    {
      id: "paystack",
      name: "Paystack",
      description: "Cards, Bank Transfers, Mobile Money",
      icon: DollarSign,
      color: "green",
    },
    {
      id: "bank_transfer",
      name: "Bank Transfer",
      description: "Direct bank transfer to your account",
      icon: Banknote,
      color: "purple",
    },
  ];

  const createPaymentMutation = useMutation({
    mutationFn: async (paymentData) => {
      const response = await fetch("/api/payments/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(paymentData),
      });
      if (!response.ok) throw new Error("Failed to create payment");
      return response.json();
    },
    onSuccess: (payment) => {
      if (selectedPaymentMethod === "stripe") {
        // Redirect to Stripe payment
        window.location.href = `/checkout/stripe?paymentId=${payment.id}`;
      } else if (selectedPaymentMethod === "paystack") {
        // Redirect to Paystack payment
        window.location.href = `/checkout/paystack?paymentId=${payment.id}`;
      } else if (selectedPaymentMethod === "bank_transfer") {
        // Show bank details confirmation
        window.location.href = `/checkout/bank-transfer?paymentId=${payment.id}`;
      }
    },
  });

  const handlePayment = async (e) => {
    e.preventDefault();

    if (!user) {
      alert("Please sign in to continue");
      return;
    }

    try {
      await createPaymentMutation.mutateAsync({
        order_id: 1, // This should come from cart/order state
        amount: cartTotal,
        payment_method: selectedPaymentMethod,
        currency: "USD",
      });
    } catch (error) {
      console.error("Payment error:", error);
      alert("Failed to process payment. Please try again.");
    }
  };

  return (
    <div
      className={`min-h-screen py-12 ${isDark ? "bg-gray-900" : "bg-gray-50"}`}
    >
      <div className="max-w-4xl mx-auto px-4">
        <div className="mb-8">
          <h1
            className={`text-3xl font-bold mb-2 ${isDark ? "text-white" : "text-gray-900"}`}
          >
            Checkout
          </h1>
          <p
            className={`text-lg ${isDark ? "text-gray-400" : "text-gray-600"}`}
          >
            Choose your preferred payment method
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6 mb-8">
          {/* Order Summary */}
          <div
            className={`md:col-span-1 ${isDark ? "bg-gray-800" : "bg-white"} rounded-lg shadow p-6`}
          >
            <h2
              className={`text-xl font-bold mb-4 ${isDark ? "text-white" : "text-gray-900"}`}
            >
              Order Summary
            </h2>
            <div className="space-y-3 mb-4 pb-4 border-b border-gray-200 dark:border-gray-700">
              <div className="flex justify-between">
                <span className={isDark ? "text-gray-400" : "text-gray-600"}>
                  Subtotal
                </span>
                <span
                  className={`font-semibold ${isDark ? "text-white" : "text-gray-900"}`}
                >
                  $45.99
                </span>
              </div>
              <div className="flex justify-between">
                <span className={isDark ? "text-gray-400" : "text-gray-600"}>
                  Delivery
                </span>
                <span
                  className={`font-semibold ${isDark ? "text-white" : "text-gray-900"}`}
                >
                  $5.00
                </span>
              </div>
              <div className="flex justify-between">
                <span className={isDark ? "text-gray-400" : "text-gray-600"}>
                  Tax
                </span>
                <span
                  className={`font-semibold ${isDark ? "text-white" : "text-gray-900"}`}
                >
                  $4.09
                </span>
              </div>
            </div>
            <div className="flex justify-between items-center mb-6">
              <span
                className={`text-lg font-bold ${isDark ? "text-gray-300" : "text-gray-700"}`}
              >
                Total
              </span>
              <span className="text-2xl font-bold text-green-600">$55.08</span>
            </div>
            <button
              disabled={true}
              className={`w-full py-2 rounded-lg ${isDark ? "bg-gray-700 text-gray-400" : "bg-gray-200 text-gray-500"} cursor-not-allowed`}
            >
              Proceed to Payment
            </button>
          </div>

          {/* Payment Methods */}
          <div className="md:col-span-2 space-y-6">
            {/* Payment Method Selection */}
            <div
              className={`${isDark ? "bg-gray-800" : "bg-white"} rounded-lg shadow p-6`}
            >
              <h2
                className={`text-xl font-bold mb-4 ${isDark ? "text-white" : "text-gray-900"}`}
              >
                Select Payment Method
              </h2>
              <div className="space-y-3">
                {paymentMethods.map((method) => {
                  const Icon = method.icon;
                  return (
                    <label
                      key={method.id}
                      className="flex items-center p-4 border-2 rounded-lg cursor-pointer transition-all"
                      style={{
                        borderColor:
                          selectedPaymentMethod === method.id
                            ? "#16a34a"
                            : isDark
                              ? "#374151"
                              : "#e5e7eb",
                        backgroundColor:
                          selectedPaymentMethod === method.id
                            ? isDark
                              ? "#1f2937"
                              : "#f0fdf4"
                            : isDark
                              ? "transparent"
                              : "transparent",
                      }}
                    >
                      <input
                        type="radio"
                        name="payment-method"
                        value={method.id}
                        checked={selectedPaymentMethod === method.id}
                        onChange={(e) =>
                          setSelectedPaymentMethod(e.target.value)
                        }
                        className="w-4 h-4 accent-green-600"
                      />
                      <Icon className="ml-3 text-green-600" size={24} />
                      <div className="ml-3 flex-1">
                        <p
                          className={`font-semibold ${isDark ? "text-white" : "text-gray-900"}`}
                        >
                          {method.name}
                        </p>
                        <p
                          className={`text-sm ${isDark ? "text-gray-400" : "text-gray-600"}`}
                        >
                          {method.description}
                        </p>
                      </div>
                    </label>
                  );
                })}
              </div>
            </div>

            {/* Bank Transfer Details (if selected) */}
            {selectedPaymentMethod === "bank_transfer" && (
              <div
                className={`${isDark ? "bg-yellow-900/20 border-yellow-900" : "bg-yellow-50 border-yellow-200"} border rounded-lg p-4`}
              >
                <div className="flex gap-3">
                  <AlertCircle
                    className="text-yellow-600 flex-shrink-0"
                    size={20}
                  />
                  <div>
                    <h3
                      className={`font-semibold mb-2 ${isDark ? "text-yellow-400" : "text-yellow-800"}`}
                    >
                      Bank Transfer Instructions
                    </h3>
                    <p
                      className={`text-sm ${isDark ? "text-yellow-300" : "text-yellow-700"}`}
                    >
                      You will receive detailed bank transfer instructions after
                      confirming your order. Please complete the transfer within
                      48 hours.
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* Security Info */}
            <div
              className={`${isDark ? "bg-gray-800" : "bg-white"} rounded-lg shadow p-6`}
            >
              <h3
                className={`font-semibold mb-3 ${isDark ? "text-white" : "text-gray-900"}`}
              >
                Security & Guarantees
              </h3>
              <ul
                className={`space-y-2 text-sm ${isDark ? "text-gray-400" : "text-gray-600"}`}
              >
                <li>✓ Your payment information is secure and encrypted</li>
                <li>✓ We use industry-standard security protocols</li>
                <li>✓ Your data is never stored on our servers</li>
                <li>✓ All transactions are PCI DSS compliant</li>
              </ul>
            </div>

            {/* Terms */}
            <div
              className={`text-sm ${isDark ? "text-gray-400" : "text-gray-600"}`}
            >
              <p>
                By proceeding, you agree to our{" "}
                <a
                  href="#"
                  className="text-green-600 hover:text-green-700 underline"
                >
                  Terms of Service
                </a>{" "}
                and{" "}
                <a
                  href="#"
                  className="text-green-600 hover:text-green-700 underline"
                >
                  Privacy Policy
                </a>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
