"use client";

import React, { useState } from "react";
import { useTheme } from "@/contexts/ThemeContext";
import useUser from "@/utils/useUser";
import { Moon, Sun, Lock, Bell } from "lucide-react";

export default function SettingsPage() {
  const { isDark, toggleTheme } = useTheme();
  const { data: user } = useUser();
  const [mfaEnabled, setMfaEnabled] = useState(false);
  const [mfaMethod, setMfaMethod] = useState("email");
  const [showMFASetup, setShowMFASetup] = useState(false);
  const [verificationCode, setVerificationCode] = useState("");

  const handleToggleMFA = async () => {
    if (!mfaEnabled) {
      setShowMFASetup(true);
    } else {
      // Disable MFA
      try {
        const response = await fetch("/api/mfa/disable", {
          method: "POST",
        });
        if (response.ok) {
          setMfaEnabled(false);
        }
      } catch (error) {
        console.error("Error disabling MFA:", error);
      }
    }
  };

  const handleEnableMFA = async () => {
    try {
      const response = await fetch("/api/mfa/enable", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ mfa_method: mfaMethod }),
      });
      if (response.ok) {
        setMfaEnabled(true);
        setShowMFASetup(false);
      }
    } catch (error) {
      console.error("Error enabling MFA:", error);
    }
  };

  return (
    <div
      className={`min-h-screen py-12 ${isDark ? "bg-gray-900" : "bg-gray-50"}`}
    >
      <div className="max-w-2xl mx-auto px-4">
        <h1
          className={`text-3xl font-bold mb-8 ${isDark ? "text-white" : "text-gray-900"}`}
        >
          Settings
        </h1>

        {/* Theme Settings */}
        <div
          className={`${isDark ? "bg-gray-800" : "bg-white"} rounded-lg shadow p-6 mb-6`}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              {isDark ? (
                <Moon className="text-gray-400" size={24} />
              ) : (
                <Sun className="text-yellow-500" size={24} />
              )}
              <div>
                <h2
                  className={`text-lg font-semibold ${isDark ? "text-white" : "text-gray-900"}`}
                >
                  Dark Mode
                </h2>
                <p
                  className={`text-sm ${isDark ? "text-gray-400" : "text-gray-600"}`}
                >
                  {isDark
                    ? "Dark mode is currently enabled"
                    : "Switch to dark mode for easier viewing"}
                </p>
              </div>
            </div>
            <button
              onClick={toggleTheme}
              className={`relative w-14 h-8 rounded-full transition-colors ${
                isDark ? "bg-green-600" : "bg-gray-300"
              }`}
            >
              <div
                className={`absolute top-1 left-1 w-6 h-6 bg-white rounded-full transition-transform transform ${
                  isDark ? "translate-x-6" : "translate-x-0"
                }`}
              />
            </button>
          </div>
        </div>

        {/* Security Settings */}
        <div
          className={`${isDark ? "bg-gray-800" : "bg-white"} rounded-lg shadow p-6 mb-6`}
        >
          <div className="flex items-center gap-3 mb-6">
            <Lock className="text-green-600" size={24} />
            <h2
              className={`text-lg font-semibold ${isDark ? "text-white" : "text-gray-900"}`}
            >
              Security
            </h2>
          </div>

          {/* Two-Factor Authentication */}
          <div className="mb-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3
                  className={`font-semibold ${isDark ? "text-white" : "text-gray-900"}`}
                >
                  Two-Factor Authentication (2FA)
                </h3>
                <p
                  className={`text-sm ${isDark ? "text-gray-400" : "text-gray-600"}`}
                >
                  Add an extra layer of security to your account
                </p>
              </div>
              <button
                onClick={handleToggleMFA}
                className={`relative w-14 h-8 rounded-full transition-colors ${
                  mfaEnabled ? "bg-green-600" : "bg-gray-300"
                }`}
              >
                <div
                  className={`absolute top-1 left-1 w-6 h-6 bg-white rounded-full transition-transform transform ${
                    mfaEnabled ? "translate-x-6" : "translate-x-0"
                  }`}
                />
              </button>
            </div>

            {showMFASetup && !mfaEnabled && (
              <div
                className={`border-t ${isDark ? "border-gray-700" : "border-gray-200"} pt-4`}
              >
                <p
                  className={`text-sm mb-4 ${isDark ? "text-gray-400" : "text-gray-600"}`}
                >
                  Choose how you'd like to receive verification codes:
                </p>
                <div className="space-y-3 mb-4">
                  <label className="flex items-center">
                    <input
                      type="radio"
                      name="mfa-method"
                      value="email"
                      checked={mfaMethod === "email"}
                      onChange={(e) => setMfaMethod(e.target.value)}
                      className="w-4 h-4 accent-green-600"
                    />
                    <span
                      className={`ml-3 ${isDark ? "text-white" : "text-gray-900"}`}
                    >
                      Email ({user?.email})
                    </span>
                  </label>
                  <label className="flex items-center">
                    <input
                      type="radio"
                      name="mfa-method"
                      value="sms"
                      checked={mfaMethod === "sms"}
                      onChange={(e) => setMfaMethod(e.target.value)}
                      className="w-4 h-4 accent-green-600"
                    />
                    <span
                      className={`ml-3 ${isDark ? "text-white" : "text-gray-900"}`}
                    >
                      SMS
                    </span>
                  </label>
                </div>

                <div className="space-y-3">
                  <button
                    onClick={handleEnableMFA}
                    className="w-full bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors"
                  >
                    Continue
                  </button>
                  <button
                    onClick={() => setShowMFASetup(false)}
                    className={`w-full border px-4 py-2 rounded-lg transition-colors ${
                      isDark
                        ? "border-gray-600 text-gray-400 hover:bg-gray-700"
                        : "border-gray-300 text-gray-700 hover:bg-gray-50"
                    }`}
                  >
                    Cancel
                  </button>
                </div>
              </div>
            )}

            {mfaEnabled && (
              <div
                className={`mt-4 p-3 rounded-lg ${isDark ? "bg-green-900/20" : "bg-green-50"}`}
              >
                <p
                  className={`text-sm ${isDark ? "text-green-400" : "text-green-700"}`}
                >
                  ✓ Two-factor authentication is enabled
                </p>
              </div>
            )}
          </div>

          {/* Password Change */}
          <div
            className={`border-t ${isDark ? "border-gray-700" : "border-gray-200"} pt-6`}
          >
            <h3
              className={`font-semibold mb-4 ${isDark ? "text-white" : "text-gray-900"}`}
            >
              Change Password
            </h3>
            <button
              className={`px-4 py-2 rounded-lg ${
                isDark
                  ? "bg-gray-700 hover:bg-gray-600 text-white"
                  : "bg-gray-200 hover:bg-gray-300 text-gray-900"
              } transition-colors`}
            >
              Update Password
            </button>
          </div>
        </div>

        {/* Notifications */}
        <div
          className={`${isDark ? "bg-gray-800" : "bg-white"} rounded-lg shadow p-6`}
        >
          <div className="flex items-center gap-3 mb-6">
            <Bell className="text-blue-600" size={24} />
            <h2
              className={`text-lg font-semibold ${isDark ? "text-white" : "text-gray-900"}`}
            >
              Notifications
            </h2>
          </div>

          <div className="space-y-4">
            {[
              { name: "Order Updates", checked: true },
              { name: "Delivery Notifications", checked: true },
              { name: "New Produce Alerts", checked: true },
              { name: "Promotional Emails", checked: false },
            ].map((notification) => (
              <div
                key={notification.name}
                className="flex items-center justify-between"
              >
                <span className={isDark ? "text-gray-300" : "text-gray-700"}>
                  {notification.name}
                </span>
                <input
                  type="checkbox"
                  defaultChecked={notification.checked}
                  className="w-5 h-5 accent-green-600 rounded"
                />
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
