import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const {
      order_id,
      amount,
      payment_method,
      currency = "USD",
    } = await request.json();

    if (!order_id || !amount || !payment_method) {
      return Response.json(
        { error: "order_id, amount, and payment_method are required" },
        { status: 400 },
      );
    }

    if (!["stripe", "paystack", "bank_transfer"].includes(payment_method)) {
      return Response.json(
        { error: "Invalid payment method" },
        { status: 400 },
      );
    }

    // Create payment record
    const payment = await sql`
      INSERT INTO payments (
        order_id,
        customer_id,
        amount,
        payment_method,
        currency,
        payment_status
      ) VALUES (
        ${order_id},
        ${session.user.id},
        ${amount},
        ${payment_method},
        ${currency},
        'pending'
      )
      RETURNING *
    `;

    return Response.json(payment[0]);
  } catch (error) {
    console.error("Error creating payment:", error);
    return Response.json(
      { error: "Failed to create payment" },
      { status: 500 },
    );
  }
}
