"use client";

import { useState } from "react";
import useAuth from "@/utils/useAuth";
import { Eye, EyeOff, Leaf, ShoppingBag } from "lucide-react";

export default function SignUpPage() {
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [userType, setUserType] = useState("customer");

  const { signUpWithCredentials } = useAuth();

  const onSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    if (!email || !password || !name) {
      setError("Please fill in all fields");
      setLoading(false);
      return;
    }

    if (password.length < 6) {
      setError("Password must be at least 6 characters");
      setLoading(false);
      return;
    }

    try {
      // Store user type in localStorage for onboarding
      localStorage.setItem("userType", userType);

      await signUpWithCredentials({
        email,
        password,
        name,
        callbackUrl:
          userType === "farmer" ? "/onboarding/farmer" : "/dashboard",
        redirect: true,
      });
    } catch (err) {
      const errorMessages = {
        EmailCreateAccount:
          "This email is already registered. Try signing in instead.",
        AccessDenied: "You don't have permission to sign up.",
      };

      setError(
        errorMessages[err.message] || "Something went wrong. Please try again.",
      );
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-screen w-full items-center justify-center bg-gradient-to-br from-green-50 to-emerald-50 p-4 dark:from-gray-900 dark:to-gray-800">
      <form
        noValidate
        onSubmit={onSubmit}
        className="w-full max-w-md rounded-2xl bg-white p-8 shadow-xl dark:bg-gray-800"
      >
        <div className="mb-8 text-center">
          <h1 className="text-3xl font-bold text-green-600 dark:text-green-400">
            BetterEat247
          </h1>
          <p className="mt-2 text-gray-600 dark:text-gray-400">
            Join our farm-to-table community
          </p>
        </div>

        <h2 className="mb-6 text-center text-xl font-bold text-gray-800 dark:text-white">
          Create Your Account
        </h2>

        <div className="space-y-6">
          {/* User Type Selection */}
          <div className="space-y-3">
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
              I want to
            </label>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setUserType("customer")}
                className={`rounded-lg border-2 p-4 text-center transition-all ${
                  userType === "customer"
                    ? "border-green-600 bg-green-50 dark:border-green-400 dark:bg-green-900/20"
                    : "border-gray-200 bg-white dark:border-gray-600 dark:bg-gray-700"
                }`}
              >
                <ShoppingBag
                  className="mx-auto mb-2 text-green-600 dark:text-green-400"
                  size={24}
                />
                <p className="font-medium text-gray-900 dark:text-white">
                  Shop Fresh
                </p>
                <p className="text-xs text-gray-600 dark:text-gray-400">
                  Buy produce
                </p>
              </button>
              <button
                type="button"
                onClick={() => setUserType("farmer")}
                className={`rounded-lg border-2 p-4 text-center transition-all ${
                  userType === "farmer"
                    ? "border-green-600 bg-green-50 dark:border-green-400 dark:bg-green-900/20"
                    : "border-gray-200 bg-white dark:border-gray-600 dark:bg-gray-700"
                }`}
              >
                <Leaf
                  className="mx-auto mb-2 text-green-600 dark:text-green-400"
                  size={24}
                />
                <p className="font-medium text-gray-900 dark:text-white">
                  Sell Produce
                </p>
                <p className="text-xs text-gray-600 dark:text-gray-400">
                  Farm seller
                </p>
              </button>
            </div>
          </div>

          {/* Name */}
          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
              Full Name
            </label>
            <input
              required
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="John Doe"
              className="w-full rounded-lg border border-gray-300 bg-gray-50 px-4 py-3 text-gray-900 placeholder-gray-500 focus:border-green-500 focus:outline-none focus:ring-2 focus:ring-green-200 dark:border-gray-600 dark:bg-gray-700 dark:text-white dark:placeholder-gray-400 dark:focus:ring-green-900"
            />
          </div>

          {/* Email */}
          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
              Email
            </label>
            <input
              required
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@example.com"
              className="w-full rounded-lg border border-gray-300 bg-gray-50 px-4 py-3 text-gray-900 placeholder-gray-500 focus:border-green-500 focus:outline-none focus:ring-2 focus:ring-green-200 dark:border-gray-600 dark:bg-gray-700 dark:text-white dark:placeholder-gray-400 dark:focus:ring-green-900"
            />
          </div>

          {/* Password */}
          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
              Password
            </label>
            <div className="relative">
              <input
                required
                type={showPassword ? "text" : "password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Create a strong password"
                className="w-full rounded-lg border border-gray-300 bg-gray-50 px-4 py-3 text-gray-900 placeholder-gray-500 focus:border-green-500 focus:outline-none focus:ring-2 focus:ring-green-200 dark:border-gray-600 dark:bg-gray-700 dark:text-white dark:placeholder-gray-400 dark:focus:ring-green-900"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 dark:text-gray-400"
              >
                {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
              </button>
            </div>
            <p className="text-xs text-gray-500 dark:text-gray-400">
              At least 6 characters
            </p>
          </div>

          {error && (
            <div className="rounded-lg bg-red-50 p-3 text-sm text-red-600 dark:bg-red-900/20 dark:text-red-400">
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full rounded-lg bg-green-600 px-4 py-3 text-base font-medium text-white transition-colors hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 disabled:opacity-50 dark:focus:ring-offset-gray-800"
          >
            {loading ? "Creating Account..." : "Create Account"}
          </button>

          <p className="text-center text-xs text-gray-600 dark:text-gray-400">
            By signing up, you agree to our Terms of Service and Privacy Policy
          </p>

          <p className="text-center text-sm text-gray-600 dark:text-gray-400">
            Already have an account?{" "}
            <a
              href="/account/signin"
              className="font-medium text-green-600 hover:text-green-700 dark:text-green-400"
            >
              Sign in
            </a>
          </p>
        </div>
      </form>
    </div>
  );
}
